# **Multiplayer**

Below is a picture of the single player field.
All elements of the field are described.