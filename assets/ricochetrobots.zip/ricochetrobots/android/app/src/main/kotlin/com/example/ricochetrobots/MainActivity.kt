package com.example.ricochetrobots

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
